function [index] = idx(radio,angulo,angulos)
%IDX Summary of this function goes here
%   Detailed explanation goes here
    index = angulo+(radio-1)*angulos;
end

