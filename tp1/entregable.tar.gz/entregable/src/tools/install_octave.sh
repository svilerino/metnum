sudo apt-add-repository ppa:octave/stable
sudo apt-get update
sudo apt-get install octave