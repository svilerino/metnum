#include "tests.h"
int main(int argc, char** argv){
	run_test();
}